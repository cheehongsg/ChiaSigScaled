// ChiaSig: detection of significant interactions in ChIA-PET data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2014) Jonas Paulsen

#ifndef GUARD_CCCDataReader
#define GUARD_CCCDataReader

#include <string>
#include <map>
#include "CCCMatrix.h"
#include <vector>

class CCCDataReader {
 public:
  CCCDataReader(std::string);  
  void buildContactMatrices();
  CCCMatrix<int> getContactMatrix(std::string);
  std::vector<CCCMatrix<int> > getContactMatrices();
  std::vector<std::string> getChromosomes();
 private:
  std::string filePath;
  std::map<std::string,CCCMatrix<int> > contactMatrices;
};
#endif
