// ChiaSig: detection of significant interactions in ChIA-PET data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2014) Jonas Paulsen

#include <set>
#include <fstream>
#include <sstream>
#include <assert.h>
#include "CCCDataReader.h"
#include "Segment.h"
#include <iostream>

using namespace std;

CCCDataReader::CCCDataReader(string file) {  
  // The constructor determines the unique segments, and nothing more.
  // These are needed for all downstream analyses.
  // Currently, this is only based on intra-data.
  filePath = file;

  ifstream inFile(filePath.c_str());
  assert(inFile.good());
  string chrL, chrR;
  int startL, endL, startR, endR, nij;

  // Get information about (unique) Segments:
  map<string, set<Segment> > segs;
  while (inFile >> chrL >> startL >> endL >> chrR >> startR >> endR >> nij) {
    assert(chrL == chrR); // Only support intra-data at the moment.
    Segment segL(chrL, startL, endL);
    Segment segR(chrR, startR, endR);

    segs[chrL].insert(segL);
    segs[chrR].insert(segR);

  }

  // Loop through chromosomes, and build empty matrices:
  typedef map<string, set<Segment> >::iterator it_type;
  for(it_type iterator = segs.begin(); iterator != segs.end(); iterator++) {      
    CCCMatrix<int> mat(iterator->second, iterator->second, 0, true);
    contactMatrices[iterator->first] = mat;
  }
  inFile.close();
}
  

void CCCDataReader::buildContactMatrices() {
  ifstream inFile(filePath.c_str());
  string chrL, chrR;
  int startL, endL, startR, endR, nij;
  assert(inFile.good());
  while (inFile >> chrL >> startL >> endL >> chrR >> startR >> endR >> nij) {
  //while (inFile >> chrL >> startL >> endL >> chrR >> startR >> endR >> nij) {
    assert(chrL == chrR); // Only support intra-data at the moment.
    Segment segL(chrL, startL, endL);
    Segment segR(chrR, startR, endR);
    
    contactMatrices[chrL].setElement(segL, segR, nij);

  }
  inFile.close();  
}

CCCMatrix<int> CCCDataReader::getContactMatrix(string chr) {
  return contactMatrices[chr];
}

vector<CCCMatrix<int> > CCCDataReader::getContactMatrices() {
  vector<string> chromosomes = this->getChromosomes();
  vector<CCCMatrix<int> > res;
  typedef vector<string>::iterator it;
  for(it iter=chromosomes.begin(); iter != chromosomes.end(); iter++) {
    res.push_back(this->getContactMatrix(*iter));
  }
  return res;
}


vector<string> CCCDataReader::getChromosomes() {
  vector<string> res;
  typedef map<string,CCCMatrix<int> >::iterator it;
  for(it iter=contactMatrices.begin(); iter!=contactMatrices.end(); iter++) {
    res.push_back(iter->first);
  }
  return res;
}
