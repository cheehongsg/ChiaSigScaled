// ChiaSig: detection of significant interactions in ChIA-PET data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2014) Jonas Paulsen


#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"
#include "../CCCsig/CCCDataReader.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

#include <cstdio>
#include <cstdlib>
#include <vector>

#include "../stocc/stocc.h" // Non-central hypergeometric

#include "../tclap-1.2.1/include/tclap/CmdLine.h" // Command-line parsing

using namespace std;


void print_spline(spline s1, spline s2, vector<double> deltas, bool errstream = true) {
  for(unsigned int i=0; i != deltas.size(); i++) {
    if (errstream) {
      cerr << deltas[i] << " " << s1(deltas[i]) << " " << s2(deltas[i]) << endl;    
    }
    else {
      cout << deltas[i] << " " << s1(deltas[i]) << " " << s2(deltas[i]) << endl;    
    }
  } 
}


int main(int argc, char** argv) {
    	try {  
	TCLAP::CmdLine cmd("ChiaSig is a program to find significant interactions in ChIA-PET datasets, using the Non-central Hypergeometric (NCHG) distribution. For details about this statistical method, see Paulsen et al. 'A statistical model of ChIA-PET data for accurate detection of chromatin 3D interactions', Nucleic acids research. (2014).\n Copyright (2014) Jonas Paulsen" , ' ', "0.91");

	TCLAP::ValueArg<unsigned int> percentilesArg("n","quantiles","Number of quantiles to use for estimating the expected number of interactions given the genomic distance (default is 500). Higher numbers (1000 and more) are appropriate for very large datasets, with many interacting anchors, while lower numbers (some hundred) will be appropriate for smaller datasets.",false,500,"int");
	cmd.add( percentilesArg );

	TCLAP::ValueArg<double> alphaArg("a","alpha","False discovery rate for selecting significant interactions (default is 0.05).",false,0.05,"double");
	cmd.add( alphaArg );


	TCLAP::ValueArg<unsigned int> cutoffArg("c","cutoff","Minimum allowed number of interactions for a given pair of anchors, to consider it significant (default is 3)",false,3,"int");
	cmd.add( cutoffArg );

	TCLAP::ValueArg<double> refinealphaArg("A","refinealpha","False discovery rate used for refinement (default is 0.01).",false,0.01,"double");
	cmd.add( refinealphaArg );


	TCLAP::ValueArg<unsigned int> refinecutoffArg("C","refinecutoff","Minimum allowed number of interactions for a given pair of anchors, to consider it significant during refinement (default is 3)",false,3,"int");
	cmd.add( refinecutoffArg );

	TCLAP::ValueArg<unsigned int> stepsArg("s","steps","Number of steps used to calculate false discovery rate (default is 4). Higher numbers will give more accurate estimation of the false discovery rate, but will also be slower.",false,4,"int");
	cmd.add( stepsArg );

	TCLAP::ValueArg<unsigned int> refinestepsArg("S","refinesteps","Number of steps used to calculate false discovery rate, during refinement (default is 4). Higher numbers will give more accurate estimation of the false discovery rate, but will also be slower.",false,4,"int");
	cmd.add( refinestepsArg );

	TCLAP::SwitchArg printdeltaSwitch("d","printdelta","Print estimated expectation values to stderr", false);
	cmd.add( printdeltaSwitch );

	TCLAP::SwitchArg onlyprintdeltaSwitch("o","onlyprintdelta","Estimate the expectation values one time (no refinement), then print estimated expectation values to stdout and exit. No P-values are calculated. Suitable for exploring the effect of choosing different number of quantiles (-n).", false);
	cmd.add( onlyprintdeltaSwitch );


	TCLAP::ValueArg<int> mindeltaArg("m","mindelta","Minumum genomic distance (in bp) allowed between anchor pairs, below which interactions are excluded. (default is 8000 bp)",false,8000,"int");
	cmd.add( mindeltaArg );


	TCLAP::ValueArg<int> maxdeltaArg("M","maxdelta","Maximum genomic distance (in bp) allowed between anchor pairs, above which interactions are excluded. (Default is no maximum value)",false,MAXDELTA,"int");
	cmd.add( maxdeltaArg );

	TCLAP::UnlabeledValueArg<string> nolabel( "filename", "Input file of the format chrA startA endA chrB startB endB I(A,B) where I(A,B) gives the number of interactions between A and B. This corresponds to the BEDPE format described here: http://bedtools.readthedocs.org/en/latest/content/general-usage.html#bedpe-format", true, "/dev/null", "filename"  );
	cmd.add( nolabel );

	cmd.parse( argc, argv );

	unsigned int percentiles = percentilesArg.getValue();
	int minDelta = mindeltaArg.getValue();
	int maxDelta = maxdeltaArg.getValue();
	bool printDelta = printdeltaSwitch.getValue();
	bool onlyprintDelta = onlyprintdeltaSwitch.getValue();
	string fileName = nolabel.getValue();
	double alphaCut = alphaArg.getValue();
	unsigned int cutoff = cutoffArg.getValue();

	unsigned int steps= stepsArg.getValue();
	unsigned int refinesteps= refinestepsArg.getValue();

	double refinealphaCut = refinealphaArg.getValue();
	unsigned int refinecutoff = refinecutoffArg.getValue();

	assert(cutoff >= 0);
	assert(refinecutoff >= 0);
	assert(steps >= 0);
	assert(refinesteps >= 0);
	assert(minDelta >= 0);	
	assert(refinesteps > 0);
	assert(alphaCut > 0 and alphaCut <= 1);
	assert(refinealphaCut > 0 and refinealphaCut <= 1);


	// READING THE DATA:
	CCCDataReader dr(fileName);
	dr.buildContactMatrices();
	vector<string> chromosomes=dr.getChromosomes();
	int deltaCutoff=minDelta;

	//cout << "Data reading done!" << endl;
	
	// Build contact-matrices:
	map<string, ContactMatrix> contactMatrices;
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
 	  string chr=chromosomes[i];
	  contactMatrices[chr] = dr.getContactMatrix(chr);
	}

	//cout << "Matrix building done!" << endl;

	// Estimate the spline-object, for the first time:

	pair<spline, vector<double> > splineObj = estimateDeltaSpline(chromosomes, contactMatrices, deltaCutoff, MAXDELTA, false, percentiles); // Spline is estimated on all delta>minDelta
	spline s = splineObj.first;
	vector<double> deltas = splineObj.second;

	if(onlyprintDelta) {
	  int dmax = (maxDelta == MAXDELTA) ? deltas.back() / 100 : maxDelta;
	  vector<double> d = getSequence((double)deltaCutoff, (double)dmax, 2000);
	  print_spline(s, s, d, false);
	  return 0;
	}
  
	map<string, ExpectationMatrix> expectationMatrices;
	map<string, PvalueMatrix> pvalMatrices;

	// Calculating P-values (first time):
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  string chr=chromosomes[i];
	  expectationMatrices[chr] = createExpectationMatrix(contactMatrices[chr], s, minDelta, MAXDELTA); // Expectations are calculated for all deltas>minDelta
	  pvalMatrices[chr] = calculatePvalues(contactMatrices[chr], expectationMatrices[chr], deltaCutoff, MAXDELTA);// During refinement, all P-values for all deltas are considered!
	}
  
	// Masking, based on P-values, using the double procedure:

	double alphaMask=refinealphaCut;
	map<double, double> FDRs = estimateFDR(chromosomes, contactMatrices, expectationMatrices, pvalMatrices, 0, alphaMask/100, 6, refinecutoff, deltaCutoff, maxDelta); 
	pair<double, double> alphaRange = getAlphaRange(FDRs, alphaMask);


	for(unsigned int i=0; i != (refinesteps-1); i++) {
	  FDRs = estimateFDR(chromosomes, contactMatrices, expectationMatrices, pvalMatrices, alphaRange.first, alphaRange.second, 6, refinecutoff, deltaCutoff, maxDelta); 
	  alphaRange = getAlphaRange(FDRs, alphaMask);
	}

	cerr << "# Masking P-value cutoff: " << alphaRange.first << ". FDR<=" << FDRs[alphaRange.first] << endl;

	// Masking data at the selected range:
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  string chr=chromosomes[i];
	  maskByAlpha(pvalMatrices[chr], contactMatrices[chr], alphaRange.first, cutoff);
	}

	// cout << "Masking done!" << endl;

	// Re-estimating the delta-function:
	splineObj = estimateDeltaSpline(chromosomes, contactMatrices, deltaCutoff, MAXDELTA, true, percentiles);
	spline sRefined = splineObj.first;
	vector<double> deltasRefined=splineObj.second;
	
	// Re-estimating expectations and P-values, now with updated expectations/lambdas:
	
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  string chr=chromosomes[i];
	  expectationMatrices[chr] = createExpectationMatrix(contactMatrices[chr], sRefined, minDelta, MAXDELTA);
	  pvalMatrices[chr] = calculatePvalues(contactMatrices[chr], expectationMatrices[chr], deltaCutoff, maxDelta); // Now, only delta-selected matrices are used
	}

	// Re-estimating FDR on new P-values:

	FDRs = estimateFDR(chromosomes, contactMatrices, expectationMatrices, pvalMatrices, 0, alphaCut/100, 6, cutoff, deltaCutoff, maxDelta); 
	alphaRange = getAlphaRange(FDRs, alphaCut);

	for(unsigned int i=0; i!=steps-1; i++) {
	  FDRs = estimateFDR(chromosomes, contactMatrices, expectationMatrices, pvalMatrices, alphaRange.first, alphaRange.second, 6, cutoff, deltaCutoff, maxDelta); 
	  alphaRange = getAlphaRange(FDRs, alphaCut);
	}
	cerr << "# Refined P-value cutoff: " << alphaRange.first << ". FDR<=" << FDRs[alphaRange.first] << endl;

	//Print the final, significant interactions:
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  string chr=chromosomes[i];
	  printPositives(pvalMatrices[chr], contactMatrices[chr], alphaRange.first, cutoff);
	}

	// Print the estimated expectation values:
	if(printDelta) {
	  print_spline(s, sRefined, deltas);
	}


	} catch (TCLAP::ArgException &e)  // catch any exceptions
	{ 
	  std::cerr << "error: " << e.error() << " for arg " << e.argId() << std::endl; 
	}


  return 0;

}

