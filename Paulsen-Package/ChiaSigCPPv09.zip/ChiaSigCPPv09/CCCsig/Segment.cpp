// ChiaSig: detection of significant interactions in ChIA-PET data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2014) Jonas Paulsen


#include "Segment.h"

using namespace std;

Segment::Segment(string c, int s, int e) {
  chr = c;
  start = s;
  end = e;
  pos = (s+e)/2;  
}
