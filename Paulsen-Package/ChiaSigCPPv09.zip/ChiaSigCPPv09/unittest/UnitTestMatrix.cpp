#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

using namespace std;

int main( int argc, char *argv[] ) {
  Segment seg1("chr1", 1, 2);
  Segment seg2("chr1", 2, 3);
  Segment seg3("chr1", 3, 4);
  
  set<Segment> rowvec;
  
  rowvec.insert(seg1);
  rowvec.insert(seg2);
  rowvec.insert(seg3);

  Segment seg4("chr2", 1, 2);
  Segment seg5("chr2", 2, 3);
  Segment seg6("chr2", 3, 4);
  set<Segment> colvec;
  colvec.insert(seg4);
  colvec.insert(seg5);
  colvec.insert(seg6);

  //cout << "Testing intrachromosomal matrix" << endl;
  //cout << "Testing instantiation and getElement" << endl;
  CCCMatrix<int> myintramat(rowvec,rowvec, 3, true);
  assert(myintramat.getElement(seg3, seg1) == myintramat.getElement(seg1, seg3));
  assert(myintramat.getElement(seg3, seg1) == 3);


  //cout << "Testing setElement" << endl;
  myintramat.setElement(seg3, seg1, 4);
  assert(myintramat.getElement(seg3, seg1) == myintramat.getElement(seg1, seg3));
  assert(myintramat.getElement(seg3, seg1) == 4);


  
  //cout << "Testing interchromosomal matrix" << endl;
  CCCMatrix<int> myintermat(rowvec,colvec, 2, false);

  //cout << "Testing instantiation and getElement" << endl;
  assert(myintermat.getElement(seg1, seg4) == 2);
  assert(myintermat.getElement(seg1, seg5) == 2);

  //cout << "Testing setElement" << endl;
  myintermat.setElement(seg1, seg4, 8);
  assert(myintermat.getElement(seg1, seg4) == 8);
  assert(myintermat.getElement(seg1, seg5) == 2);

  //cout << "Testing row and column sums" << endl;
  myintramat.setElement(seg1, seg2, 9);
  myintramat.setElement(seg1, seg1, 0);
  myintramat.setElement(seg2, seg2, 2);

  // Intra-matrices are symmetric, thus row and column sums should be equal:
  assert(myintramat.rowSum(seg1) == myintramat.colSum(seg1));
  assert(myintramat.rowSum(seg2) == myintramat.colSum(seg2));
  assert(myintramat.rowSum(seg3) == myintramat.colSum(seg3));

  assert(myintramat.colSum(seg1) == 13);
  assert(myintramat.colSum(seg2) == 14);
  assert(myintramat.colSum(seg3) == 10);

  myintermat.setElement(seg2, seg4, 1);
  myintermat.setElement(seg1, seg4, 9);
  myintermat.setElement(seg2, seg5, 0);
  myintermat.setElement(seg3, seg5, 3);

  assert(myintermat.rowSum(seg1) == 13);
  assert(myintermat.rowSum(seg2) == 3);
  assert(myintermat.rowSum(seg3) == 7);

  assert(myintermat.colSum(seg4) == 12);
  assert(myintermat.colSum(seg5) == 5);
  assert(myintermat.colSum(seg6) == 6);


  // Testing masking of matrices
  //cout << "Testing masking of matrices" << endl;
  myintramat.setMask(seg1, seg2);

  //cout << "Without masking:" << endl;
  //myintramat.printMatrix(false);
  //cout << "With masking:" << endl;
  //myintramat.printMatrix(true);

  assert(  myintramat.isMasked(seg1, seg2) );
  assert(  not myintramat.isMasked(seg1, seg3) );


  cout << argv[0] << ": Success!" << endl;

  return 0;
}
