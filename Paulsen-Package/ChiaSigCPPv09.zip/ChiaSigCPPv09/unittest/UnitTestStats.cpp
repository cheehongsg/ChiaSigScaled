#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>


using namespace std;

int main( int argc, char *argv[] ) {
  /*
  Segment seg1("chr1", 1, 2);
  Segment seg2("chr1", 3, 4);
  Segment seg3("chr1", 5, 6);
  Segment seg4("chr1", 10, 11);
  Segment seg5("chr1", 12, 13);
  
  set<Segment> rowvec;
  
  rowvec.insert(seg1);
  rowvec.insert(seg2);
  rowvec.insert(seg3);
  rowvec.insert(seg4);
  rowvec.insert(seg5);

  CCCMatrix<int> myintramat(rowvec,rowvec, 3, true);
  myintramat.setElement(seg1,seg2,1);
  myintramat.setElement(seg1,seg3,2);
  myintramat.setElement(seg2,seg3,3);
  myintramat.setElement(seg2,seg4,0);
  myintramat.setElement(seg2,seg5,5);
  myintramat.setElement(seg4,seg5,2);
  myintramat.setElement(seg5,seg5,0);
  cout << "--- Matrix: ----" << endl;
  myintramat.printMatrix();
  cout << "--- ------- ----" << endl;
  map<int, vector<int> > delta2value = getValuesPerDelta(myintramat);
  */

  typedef map<int, vector<int> >::iterator It;
  /*
  for (It i = delta2value.begin(); i != delta2value.end(); ++i) {
    vector<int> vals = i->second;
    cout << i->first;
    for(int j=0; j < vals.size(); j++) {
      cout << " " << vals[j];
    }
    cout << endl;
  }
  */ 
  /*
  vector<int> deltas = myintramat.getDeltas();
  sort(deltas.begin(), deltas.end());
  cout << "deltas:";
  for(int i=0; i!=deltas.size(); i++) {
    cout << deltas[i] << " ";
  }
  cout << endl;

  map<int,int> hei = computeQuantileMapper(deltas, 3);
  */
  
  typedef map<int, int>::const_iterator it;
  /*
  for (it iter = hei.begin(); iter != hei.end(); iter++) {
    cout << "Key: " << iter->first << " Value:" << iter->second << endl;
  }
  */

  // Unit tests:
  // CASE 1:
  // Divides correctly, but bleeds over in the beginning:
  vector<int> deltas2;
  deltas2.push_back(2);
  deltas2.push_back(2);
  deltas2.push_back(2);
  deltas2.push_back(2);
  deltas2.push_back(3);
  deltas2.push_back(3);
  deltas2.push_back(3);
  deltas2.push_back(4);
  deltas2.push_back(4);
  //cout << "vec: 2 2 2 2 3 3 3 4 4 " << endl;
  map<int,int> hei2 = computeQuantileMapper(deltas2, 3);

  assert(hei2[2] == 2);
  assert(hei2[3] == 3);
  assert(hei2[4] == 4);

  // CASE 2:
  // No beedover, but divides badly:
  vector<int> deltas3;
  deltas3.push_back(2);
  deltas3.push_back(3);
  deltas3.push_back(4);
  deltas3.push_back(5);
  deltas3.push_back(6);
  deltas3.push_back(7);
  deltas3.push_back(8);
  deltas3.push_back(9);
  deltas3.push_back(10);
  //cout << "vec: 2 3 4 5 6 7 8 9 10 " << endl;
  map<int,int> hei3 = computeQuantileMapper(deltas3, 4);

  assert(hei3[2] == 2);
  assert(hei3[3] == 2);
  assert(hei3[4] == 4);
  assert(hei3[5] == 4);
  assert(hei3[6] == 6);
  assert(hei3[7] == 6);
  assert(hei3[8] == 8);
  assert(hei3[9] == 8);
  assert(hei3[10] == 8);


  // CASE 3:
  // Both beedove, and divides badly:
  vector<int> deltas4;
  deltas4.push_back(2);
  deltas4.push_back(2);
  deltas4.push_back(2);
  deltas4.push_back(2);
  deltas4.push_back(3);
  deltas4.push_back(4);
  deltas4.push_back(5);
  deltas4.push_back(6);
  deltas4.push_back(10);
  //cout << "vec: 2 2 2 2 3 4 5 6 10 " << endl;

  map<int,int> hei4 = computeQuantileMapper(deltas4, 4);
  // In this case, we have so many 2's that two of the quantiles will be spent on the 2's only
  assert(hei4[2] == 2); // all 2's should map to two.
  assert(hei4[3] == 3);
  assert(hei4[4] == 3);
  assert(hei4[5] == 5);
  assert(hei4[6] == 5);
  assert(hei4[10] == 5); // In this case, since we have spent two of the chunks on the 2s, the last will map to 5 as well.
  


  // CASE 4:
  // All values equal
  vector<int> deltas5;
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  deltas5.push_back(2);
  //cout << "vec: 2 2 2 2 2 2 2 2 2 " << endl;
  map<int,int> hei5 = computeQuantileMapper(deltas5, 4);

  assert(hei5[2] == 2); // all 2's should map to two.

  
  // CASE 5:
  // Well-working example:
  //cout << "---" << endl;
  vector<int> deltas6;
  for(int i=0; i!=100; i++) {
    deltas6.push_back(i);
  }
  map<int,int> hei6 = computeQuantileMapper(deltas6, 4);

  assert(hei6[0] == 12);
  assert(hei6[24] == 12);
  assert(hei6[25] == 37);
  assert(hei6[49] == 37);
  assert(hei6[49] == 37);
  assert(hei6[50] == 62);
  assert(hei6[74] == 62);
  assert(hei6[75] == 87);
  assert(hei6[99] == 87);


  // CASE 6:
  // Sort-of well-working example:

  vector<int> deltas7;
  for(int i=0; i!=89; i++) {
    deltas7.push_back(i);
  }
  map<int,int> hei7 = computeQuantileMapper(deltas7, 4);

  // first 22 values:
  assert(hei7[0] == 10);
  assert(hei7[21] == 10);

  // second 22 values
  assert(hei7[22] == 32);
  assert(hei7[43] == 32);

  // third 22 values:
  assert(hei7[44] == 54);
  assert(hei7[65] == 54);

  // Last values
  assert(hei7[66] == 76);
  assert(hei7[88] == 76); // Last, single value is the same as the previous quantile

  cout << argv[0] << ": Success!" << endl;
  return 0;
}
