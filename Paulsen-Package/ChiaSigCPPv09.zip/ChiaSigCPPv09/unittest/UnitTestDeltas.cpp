#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"
#include "../CCCsig/CCCDataReader.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>


using namespace std;


// Allowing for vector concatenation via addition:
/*
template <typename T>
vector<T> operator+(const vector<T> &A, const vector<T> &B)
{
    vector<T> AB;
    AB.reserve( A.size() + B.size() );         
    AB.insert( AB.end(), A.begin(), A.end() ); 
    AB.insert( AB.end(), B.begin(), B.end() ); 
    return AB;
}

template <typename T>
vector<T> &operator+=(vector<T> &A, const vector<T> &B)
{
    A.reserve( A.size() + B.size() );          
    A.insert( A.end(), B.begin(), B.end() );   
    return A;                                  
}
*/


int main( int argc, char *argv[] ) {
  /* 
  // READING REAL DATA:
  CCCDataReader dr("/Users/jonaspau/Projects/ChiaSig/data/K562Pol2.bedpe");
  dr.buildContactMatrices();
  vector<string> chromosomes=dr.getChromosomes();
  CCCMatrix<int> mat;
  vector<int> deltas;
  for(int i=0; i!=chromosomes.size(); i++) {
     mat = dr.getContactMatrix(chromosomes[i]);
     deltas+=mat.getDeltas();
  }
  
  map<int,int> quantileMapper = computeQuantileMapper(deltas, 1000);
  
  map<int, vector<int> > delta2vals = getValuesPerDelta(dr.getContactMatrices(), quantileMapper);
  map<int, float> delta2exps = getMeanPerDelta(delta2vals);

  typedef map<int, float>::iterator it;
  for(it iter = delta2exps.begin(); iter != delta2exps.end(); iter++) {
    cout << iter->first << " " << iter->second << endl;
  }
  */

  vector<int> vec1;
  vec1.push_back(1);
  vec1.push_back(2);
  vec1.push_back(3);
  vec1.push_back(4);

  vector<int> vec2;
  vec2.push_back(5);
  vec2.push_back(5);
  vec2.push_back(5);
  vec2.push_back(5);

  vector<int> vec3;
  vec3.push_back(1);

  vector<int> vec4;
  vec4.push_back(0);
  vec4.push_back(1);


  map<int, vector<int> > mymap;
  mymap[0] = vec1;
  mymap[1] = vec2;
  mymap[2] = vec3;
  mymap[3] = vec4;

  map<int, float> delta2mean = getMeanPerDelta(mymap);
  
  assert(delta2mean[0] == 2.5);
  assert(delta2mean[1] == 5);
  assert(delta2mean[2] == 1);
  assert(delta2mean[3] == 0.5);

  cout << argv[0] << ": Success!" << endl;
  return 0;
}
