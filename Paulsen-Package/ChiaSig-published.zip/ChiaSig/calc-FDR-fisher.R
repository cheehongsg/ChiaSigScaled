args<-commandArgs(TRUE)

dat = read.table(args[1])
min.cut = as.numeric(args[2])

alphas = seq(as.numeric(args[3]),as.numeric(args[4]), length.out=as.numeric(args[5]))

for(alpha in alphas) {

  N.pos = sum((dat$V7 >= min.cut) & dat$V15 <= alpha)
  cut = pmax(min.cut, 1+qhyper(1-alpha,dat$V9,2*dat$V8-dat$V9,dat$V10))
  E.FP = sum(ifelse(cut==0,0, 1-phyper(cut-1,dat$V9,2*dat$V8-dat$V9,dat$V10)))
  FDR = E.FP / N.pos
  write(paste(alpha, E.FP, N.pos, E.FP/N.pos), stdout())
}

# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen