p=$6 # Number of parallel processes
file=$1

N=$(wc -l $file | awk '{print $1}')
L=$((($N+($p-1))/$p))

split -a 3 -l $L $file $file.split.

for fil in $file.split.*
do 
nohup Rscript calc-FDR.R $fil $2 $3 $4 $5 > $fil.FDR &
done
wait


# combine results:
awk '{a[$1]++; b[$1]+=$2; c[$1]+=$3 } END {for (i in a) print i,b[i],c[i],b[i]/c[i]}' $file.split.*.FDR | sort -k 4n,4n

# clean up:
rm $file.split.*