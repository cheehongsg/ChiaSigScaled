# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen

import warnings 
import numpy as np, bisect
from scipy import stats
from scipy import optimize
import rpy2.robjects as robjects
from scipy.stats import scoreatpercentile
from numpy import ma

def getDeltaPercentiles(ChiaPetData, deltaMin, nPercentiles):
    """ Returns a list of quantiles of deltas in ChiaPetData """
    #deltas = np.array(ChiaPetData.getAllDeltas(), dtype=int)
    deltas = np.array(ChiaPetData.getAllDeltas(excludeMasked=True), dtype=int)    
    percs =  list((np.array(range(0,nPercentiles)) / float(nPercentiles))*100)
    perc = scoreatpercentile(deltas[deltas>deltaMin], list(percs), interpolation_method='lower')
    return perc

def getExpPerDeltaPercentile(ChiaPetData, percentiles):
    """ For each quantile (percentiles), find corresponding deltas in ChiaPetData
    and return the average weight """
    #data = np.array(ChiaPetData.getAllData())
    data = np.array(ChiaPetData.getAllData(excludeMasked=True))
    #deltas = np.array(ChiaPetData.getAllDeltas())
    deltas = np.array(ChiaPetData.getAllDeltas(excludeMasked=True))
    res = {}
    for i in range(1, len(percentiles)):
        percLower = percentiles[i-1]
        percUpper = percentiles[i]
        #percMid = (percLower + percUpper) / 2 # mid = avg.
        percMid = np.median(deltas[(deltas >= percLower) & (deltas < percUpper)]) # mid = median
        res[percMid] = data[(deltas >= percLower) & (deltas < percUpper)].mean()
    
    # Add last percentile 
    percLast = np.median(deltas[deltas >= percUpper])
    res[percLast] = data[deltas >= percUpper].mean()
    
    return res
        
def estimateSpline(deltaList, expectationList):
    """ Estimate a cubic smoothing spline for a list of deltas
    and corresponding expectations """
    smooth_spline = robjects.r["smooth.spline"]    
    s = smooth_spline(robjects.FloatVector(deltaList), robjects.FloatVector(expectationList))
    return s

def predictBySpline(deltas, fittedSpline):
    """ For each delta (in deltas), return the corresponding
    spline value """
    predict = robjects.r["predict"]
    res = predict(fittedSpline, robjects.FloatVector(deltas))[1]
    return [r for r in res]


def makeExpFunction(functionType="smooth", data=None, expPerDelta=None, s=None, s2=None, cutoff=None):
    """ Create and return a function that maps from a pair of nodes
    to an expectation value """
    assert functionType in ['smooth', 'uniform', 'splitsmooth']
    if functionType == "smooth":
        assert s is not None, "Need a spline-object in order to smooth" 
        def smoothFunc(node1, node2):
            delta = node1-node2
            return predictBySpline([delta], s)[0]
        return smoothFunc
    elif functionType == "uniform": # This simple function always gives '1' as the expected frequency
        def uniformFunc(node1, node2):
            return 1.0
        return uniformFunc
    elif functionType == "splitsmooth":
        assert s is not None
        assert s2 is not None
        assert cutoff is not None
        def splitSmoothFunc(node1, node2):
            delta = node1-node2
            if delta < cutoff:
                return predictBySpline([delta], s)[0]
            else:
                return predictBySpline([delta], s2)[0]            
        return splitSmoothFunc
        

def doNonCentralHyperGeometricTest(Npq, Np, Nq, N, OddsRatio):
    rcmd = "fisher.test(matrix(c(%s,%s,%s,%s), ncol=2), or=%s, alternative='greater')" % (Npq,Np-Npq,Nq-Npq,(N-Np-Nq)+Npq,OddsRatio)
    pval = robjects.r(rcmd)[0][0]
    return pval
    
def doFisherTest(obs, nodeDegree1, nodeDegree2, n, tail="greater"):
    mat = [[obs, nodeDegree1-obs],[nodeDegree2-obs, (n-nodeDegree1-nodeDegree2)+obs]]
    if tail == "greater":
        OR, pval = stats.fisher_exact(mat, alternative="greater")
        return pval
    elif tail == "less":
        OR, pval = stats.fisher_exact(mat, alternative="less")
        return pval
    elif tail == "two-sided":
        OR, pval = stats.fisher_exact(mat, alternative="two-sided")
        return pval
    assert False, "Need to specify eiether 'greater', 'less', or 'two-sided'"
                    
    
def getPvalues(ChiaPetData, interactionCutoff=0, minDelta=None, glob=False, method="NCHG"):
    """ This functin returns P-values and corresponding
    pairs of segments, using the non-central Hypergeometic test or Fisher's exact test.
    
    interactionCutoff: Return only interactions above this cutoff (currently 0 is the best option)
    glob: Should the estimated parameters be based on all data across chromosomes (glob=True), or for each chromosome individually (glob=False)
    method: 'NCHG': Non-central Hypergeometric, 'Fisher': Fisher's exact test    
    """
    assert ChiaPetData.hasNodeDegrees()
    assert method in ["NCHG", "Fisher"]
    if method == "NCHG":
        assert ChiaPetData.hasExpDegrees()
    
    pvals = []
    interactions = []
    
    weightSums = [ChiaPetData[chr].get_sum_of_weights() for chr in ChiaPetData]    
    bigN = ma.sum(ma.masked_array(weightSums, mask=[s is None for s in weightSums]))
    dataSums = [ChiaPetData[chr].get_sum_of_data() for chr in ChiaPetData]    
    bigL = ma.sum(ma.masked_array(dataSums, mask=[s is None for s in dataSums]))
    for chr in ChiaPetData:
        N = ChiaPetData[chr].get_sum_of_weights() if not glob else bigN
        L = ChiaPetData[chr].get_sum_of_data() if not glob else bigL
        for node1, node2 in ChiaPetData[chr].get_nodepair_iter():
            delta = node2 - node1
            if delta <= minDelta:
                continue
            Npq = ChiaPetData[chr][node1,node2]
            Np = node1.degree
            Nq = node2.degree
            Lp = node1.exp_degree
            Lq = node2.exp_degree
            Lpq = ChiaPetData[chr].get_edge_data(node1, node2)
                       
            #if Npq is ma.masked or Lpq is ma.masked:
            #    continue
            if Npq < interactionCutoff:
                continue
            
            u =  Lpq*((2*L-Lp-Lq)+Lpq)/((Lp-Lpq)*(Lq-Lpq)) #end points
            
            if u <= 0:
                pval = "NA"
            else:
                if method == "NCHG":
                    pval = doNonCentralHyperGeometricTest(Npq, Np, Nq, 2*N, u) 
                elif method == "Fisher":
                    pval = doFisherTest(Npq, Np, Nq, 2*N)

            pvals.append(pval)
            interactions.append((node1,node2, Npq, N, Np, Nq, Lp, Lq, Lpq, u))
            
    return interactions, pvals
            

