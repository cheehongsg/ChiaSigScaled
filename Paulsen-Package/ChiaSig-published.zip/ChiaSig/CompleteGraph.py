# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen

import numpy as np
import numpy.ma as ma

class CompleteGraph:
    """ A Weighted Complete Graph, with additional data for each edge """
    def __init__(self, nodes=[], defaultWeight=0, defaultData=0.0, dtypeWeight=int, dtypeData=float):
        self._nodes = np.array(nodes)
        assert len(self._nodes) == len(np.unique(self._nodes))
        self._getNodeIndex = {node:index for index, node in enumerate(self._nodes)}
        self._dim = self._nodes.size
        
        self._weightMatrix = np.zeros((self._dim, self._dim), dtype=dtypeWeight)
        self._weightMatrix.fill(defaultWeight)

        self._dataMatrix = np.zeros((self._dim, self._dim), dtype=dtypeData)
        self._dataMatrix.fill(defaultData)

        self._maskMatrix = np.zeros((self._dim, self._dim), dtype=bool) # masking-matrix is false by default (no masking)

    
    def get_weightMatrix(self):
        return self._weightMatrix
    
    def get_dataMatrix(self):
        return self._dataMatrix
    
    def get_deltaMatrix(self):
        """Get list of distances (node1-node2) between all nodes"""
        nodeArray = np.array(self._nodes)
        nodeArray.shape = (self._dim,1)
        return nodeArray - nodeArray.T
    
    def get_deltas(self, excludeMasked=False):
        d = self.get_deltaMatrix()
        if excludeMasked:
            triu = np.triu_indices_from(d, k=1)
            return np.array(d[triu][~self._maskMatrix[triu]], dtype=int).flatten()
        return np.array(d[np.triu_indices_from(d, k=1)], dtype=int).flatten()

    def get_dim(self):
        return self._dim
        
    def get_pos(self, node1, node2):
        return (self._getNodeIndex[node1], self._getNodeIndex[node2])
    
    def set_edge_weight(self, node1, node2, weight):
        pos1, pos2 = self.get_pos(node1, node2)
        self._weightMatrix[pos1][pos2] = weight
        self._weightMatrix[pos2][pos1] = weight

    def set_edge_data(self, node1, node2, data):
        pos1, pos2 = self.get_pos(node1, node2)
        self._dataMatrix[pos1][pos2] = data
        self._dataMatrix[pos2][pos1] = data
        
    def set_edge_mask(self, node1, node2, mask):
        pos1, pos2 = self.get_pos(node1, node2)
        self._maskMatrix[pos1][pos2] = mask
        self._maskMatrix[pos2][pos1] = mask
        
    def get_edge_mask(self, node1, node2):
        pos1, pos2 = self.get_pos(node1, node2)
        return self._maskMatrix[pos1][pos2]

    def get_edge_weight(self, node1, node2):
        pos1, pos2 = self.get_pos(node1, node2)
        return self._weightMatrix[pos1][pos2]

    def get_edge_data(self, node1, node2):
        pos1, pos2 = self.get_pos(node1, node2)
        return self._dataMatrix[pos1][pos2]
    
    

    def get_weight_slice(self, node):
        return self._weightMatrix[np.where(self._nodes==node)].flatten()

    def get_data_slice(self, node):
        return self._dataMatrix[np.where(self._nodes==node)].flatten()

    def get_all_weights(self, excludeMasked=False):
        if excludeMasked:
            triu = np.triu_indices_from(self._weightMatrix, k=1)            
            return self._weightMatrix[triu][~self._maskMatrix[triu]].flatten() # upper triangular matrix, with masked values excluded
        return self._weightMatrix[np.triu_indices_from(self._weightMatrix, k=1)].flatten() # upper triangular matrix

    def get_all_data(self, excludeMasked=False):
        if excludeMasked:
            triu = np.triu_indices_from(self._dataMatrix, k=1)            
            return self._dataMatrix[triu][~self._maskMatrix[triu]].flatten()
        return self._dataMatrix[np.triu_indices_from(self._dataMatrix, k=1)].flatten()
    
    def __setitem__(self, keypair, value):
        self.set_edge_weight(keypair[0], keypair[1], value)

    def __getitem__(self, keypair):
        return self.get_edge_weight(keypair[0], keypair[1])
    
    def get_node_degree(self, node):
        return ma.sum(self.get_weight_slice(node))

    def get_sum_of_weights(self):
        res = ma.sum(self.get_all_weights())
        return res if not res is ma.masked else None
    
    def get_sum_of_data(self):
        res = ma.sum(self.get_all_data())
        return res if not res is ma.masked else None
    
    def get_node_iter(self):
        for node in self._nodes:
            yield node
    
    def get_nodepair_iter(self):
        for i in xrange(self._dim):
            for j in xrange(i+1, self._dim):
                yield self._nodes[i], self._nodes[j]
    
