# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen

class Segment:
    def __init__(self, chr, start, end):
        self.chr = chr
        self.start = int(start)
        self.end = int(end)
        self.pos = abs(self.end + self.start) / 2
        
    def __eq__(self, other):
        return self.chr == other.chr and self.start == other.start and self.end == other.end

    def __lt__(self, other):
        if self.chr == other.chr:
            return self.pos < other.pos
        else:
            return self.chr < other.chr
    def __gt__(self, other):
        if self.chr == other.chr:
            return self.pos > other.pos
        else:
            return self.chr > other.chr
    def __repr__(self):
        return self.chr + "\t" + str(self.start) + "\t" + str(self.end)

    def __str__(self):
        return self.chr + "\t" + str(self.start) + "\t" + str(self.end)
    def __hash__(self):
        return hash(self.chr + "\t" + str(self.start) + "\t" + str(self.end))
    
    def __sub__(self, other):
        return abs(self.pos - other.pos)

