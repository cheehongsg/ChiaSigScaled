#!/usr/bin/python
import sys, os
import argparse
from ChiaPetData import ChiaPetData
from ChiaPetStatistics import *

import numpy as np

# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen

def createParser():
    parser = argparse.ArgumentParser(description='Find significant interactions ')
    parser.add_argument('inFile', type=str, help="Input file of the format chrA startA endA chrB startB endB I(A,B) where I(A,B) gives the number of interaction between A and B")
    parser.add_argument('-n', "--nPercentiles", type=int, default=1000, help="Number of percentile-groups to use for expectation estimateion (default is 1000)")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-N', "--NCHG", action="store_true", help="Use the Non-central Hypergeometric model to estimate P-values (take into account both the number of involved contacts, and the sequential distance)")
    group.add_argument('-F', "--Fisher", action="store_true", help="Use the Fisher model to estimate P-values (take only into account both the number of involved contacts) ")
    
    group2 = parser.add_mutually_exclusive_group(required=True)    
    group2.add_argument('-u', "--uniform", action="store_true", help="Use a uniform model for calculating the expected contact frequencies")
    group2.add_argument('-s', "--smooth", action="store_true", help="Use a non-uniform, smoothed model for calculating the expected contact frequencies")
    group2.add_argument('-ss', "--splitsmooth", action="store_true", help="Use two non-uniform, smoothed models for calculating the expected contact frequencies")
        
    parser.add_argument('-g', "--glob", default=False, action="store_true", help="Compute P-values based on global counts (i.e. do not adjust for chromosomal differences in contact frequencies)")
    parser.add_argument('-v', "--verbose", action="store_true", help="Print lots of information about each interaction")
    parser.add_argument('-d', "--printDelta", action="store_true", help="Print estimated delta-distribution to stderr during run")

    parser.add_argument('-md', "--minDelta", type=int, default=8000, help="Minimum sequential distance allowed, below which interactions are excluded (default is 8000)")

    parser.add_argument('--version', action='version', version='%(prog)s 1.0')
    return parser
    
if __name__ == '__main__':
    parser = createParser()
    args = parser.parse_args()

    print "#", args
    if not os.path.isfile(args.inFile):
        parser.error("The input file does not exist!")
    
    data = ChiaPetData(args.inFile)
    percs = getDeltaPercentiles(data, deltaMin=args.minDelta, nPercentiles=args.nPercentiles)

    expPerDelta = getExpPerDeltaPercentile(data, percs) 

    deltas = sorted(expPerDelta.keys())
    expecs = [expPerDelta[d] for d in deltas]
    
    if args.smooth:
        s = estimateSpline(deltas, expecs)
        deltaToExp = makeExpFunction(functionType="smooth", s=s)

    elif args.splitsmooth:
        deltas = np.array(deltas)
        expecs = np.array(expecs)
        cutoff=1e+06
        s = estimateSpline(list(deltas[deltas<cutoff]), list(expecs[deltas<cutoff]))
        s2 = estimateSpline(list(deltas[deltas>=cutoff]), list(expecs[deltas>=cutoff]))
        deltaToExp = makeExpFunction(functionType="splitsmooth", s=s, s2=s2, cutoff=cutoff)

    elif args.uniform:
        deltaToExp = makeExpFunction(functionType="uniform") # Use naive/uniform expectation-model
    
    if args.printDelta:
        for i in range(len(deltas)):
            sys.stderr.write(str(deltas[i]) + " " +  str(expecs[i]) + " " + str(deltaToExp(deltas[i], 0)) + "\n")
            
    
    data.setExpectationFromPercentiles(deltaToExp)
    
    #data.maskByDelta(minDelta=args.minDelta) # Remove data with low deltas before calcing exp and node-degrees
    data.setToZeroByDelta(minDelta=args.minDelta) # Set data to zero, where delta is too low, before calculating exp- and node-degrees
                
    data.setNodeDegrees()
        
    data.setExpDegrees()
                
    if args.NCHG:
        method = "NCHG"
    elif args.Fisher:
        method = "Fisher"
        
    interactions, pvals = getPvalues(data, minDelta=args.minDelta, glob=args.glob, method=method)

    for i in range(len(interactions)):        
        node1,node2, Npq, N, Np, Nq, a1, a2, Lpq, u = interactions[i]
        P = pvals[i]
        if args.verbose:
            print node1,node2, Npq, N, Np, Nq, a1, a2, Lpq, u, P
        else:
            print node1,node2, Npq, P
    
