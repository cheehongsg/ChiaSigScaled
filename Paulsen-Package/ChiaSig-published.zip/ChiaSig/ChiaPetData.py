# ChiaSig: detection of significant interactions in ChIA-PET data
# Copyright (2014) Jonas Paulsen

from CompleteGraph import CompleteGraph
from Segment import Segment
import numpy as np
from scipy.stats import scoreatpercentile
import numpy.ma as ma

class ChiaPetData(dict):
    """ A container for ChiaPet data sets, implemented as a dict of CompleteGraphs.
        Data is read in like this: ChiaPetData(fileName), and we assume that all
        data is structured like:
        chrL startL endL chrR starR endR Count [Mask]
        Where Count is the number of interactions between segments on "left" and "right".
        [Mask] is an optional column. 1 idicates that this value should be ignored for estimation of the expectation-function, 0 otherwise. 
        All segment interaction counts should only be specified once!
        In principle. No sanity-check on the input data is done.
    """
    def __init__(self, fileName):
        inFile = open(fileName, "r")
        segmentsLeft = {} # dict of segment-lists hashed on chromosome (left side)
        segmentsRight = {} # dict of segment-lists hashed on chromosome (left side)
        counts = {} # dict of counts hashed on chromosome, for the corresponding segments
        masks = {} # dict of masking-values (True/False) for estimation of the expecation function
        self._hasExtraData = False
        self._hasNodeDegrees = False
        self._hasExpDegrees = False
        self._hasWeightSum = False
        
        for l in inFile:
            l_split = l.split()
            if len(l_split) == 7:
                chrL, startL, endL, chrR, startR, endR, count = l.split()
                mask = 0
            elif len(l_split) == 8: # The additional mask-value is specified
                chrL, startL, endL, chrR, startR, endR, count, mask = l.split()
                mask = int(mask)
                assert mask in [0, 1], "Masking-values are only allowed to be 1 or 0"
            assert chrL == chrR, "We only accept intra-chromosomal interactions (at the moment)"
            segmentL = Segment(chrL, startL, endL)
            segmentR = Segment(chrR, startR, endR)
            count = int(count)
            if not segmentsLeft.has_key(chrL):
                segmentsLeft[chrL] = []
                segmentsRight[chrL] = []
                counts[chrL] = []
                masks[chrL] = []
            segmentsLeft[chrL].append(segmentL)
            segmentsRight[chrR].append(segmentR)
            counts[chrL].append(count)
            masks[chrL].append(bool(mask))
        inFile.close()
        
        for chr in segmentsLeft:
            assert len(segmentsLeft[chr]) == len(segmentsRight[chr]) == len(counts[chr]) == len(masks[chr])
            if not self.has_key(chr):
                uniqeNodes = np.unique(segmentsLeft[chr] + segmentsRight[chr])
                self[chr] = CompleteGraph(uniqeNodes)
            for i in range(len(segmentsLeft[chr])):
                segmentL = segmentsLeft[chr][i]
                segmentR = segmentsRight[chr][i]
                assert self[chr][segmentL,segmentR] == 0, "Interaction-counts must be specified one time only"
                self[chr][segmentL,segmentR] = counts[chr][i]
                self[chr].set_edge_mask(segmentL, segmentR, masks[chr][i])

    def __repr__(self):
        return "ChiaPetData with " + str(len(self.keys())) + " chromosomes" 
        
    def hasNodeDegrees(self):
        return self._hasNodeDegrees
    
    def hasExpDegrees(self):
        return self._hasExpDegrees
        
    def hasWeightSum(self):
        return self._hasWeightSum
        
    def hasExtraData(self):
        return self._hasExtraData
        

    def setNodeDegrees(self):
        for chr in self:
            for segment in self[chr].get_node_iter():
                segment.degree = self[chr].get_node_degree(segment)
        self._hasNodeDegrees = True
    
    def setExpDegrees(self):
        assert self._hasExtraData, "setExpectationData (or similar) has to be run before this function"
        for chr in self:
            for segment in self[chr].get_node_iter():
                segment.exp_degree = ma.sum(self[chr].get_data_slice(segment))
        self._hasExpDegrees = True
        
    def setExpectationFromPercentiles(self, nodePairToExp):
        """ Put expectation-data (smoothed or non-smoothed) from a function, onto each edge in ChiaPetData.
        The nodePairToExp function should take the two nodes, and return the expected interaction frequency"""
        for chr in self:
            for segmentL, segmentR in self[chr].get_nodepair_iter():
                self[chr].set_edge_data(segmentL,segmentR, nodePairToExp(segmentL, segmentR))
        self._hasExtraData = True
    
    def getAllDeltas(self, excludeMasked=True):
        deltas = []
        chromosomes = sorted(self.keys())
        for chr in chromosomes:
            #deltas.extend(self[chr].get_deltas())
            deltas.extend(self[chr].get_deltas(excludeMasked))
        return deltas

    def getAllData(self, excludeMasked=True):
        data = []
        chromosomes = sorted(self.keys())
        for chr in chromosomes:
            #data.extend(self[chr].get_all_weights())
            data.extend(self[chr].get_all_weights(excludeMasked))
        return data
    
    def getChromosome(self, node):
        return node.chr
    
    #def maskByDelta(self, minDelta=None, maxDelta=None):
    #    for chr in self:
    #        delta = self[chr].get_deltaMatrix()
    #        if minDelta is not None:
    #            self[chr]._dataMatrix = ma.masked_where(delta<=minDelta, self[chr]._dataMatrix)
    #            self[chr]._weightMatrix = ma.masked_where(delta<=minDelta, self[chr]._weightMatrix)
    #        if maxDelta is not None:
    #            self[chr]._dataMatrix = ma.masked_where(delta>=maxDelta, self[chr]._dataMatrix)
    #            self[chr]._weightMatrix = ma.masked_where(delta>=maxDelta, self[chr]._weightMatrix)
    
    def setToZeroByDelta(self, minDelta=None, maxDelta=None):
        """ Set weights and data to zero for particular cutoff-values on delta """
        for chr in self:
            delta = self[chr].get_deltaMatrix()
            if minDelta is not None:
                self[chr]._dataMatrix[delta<=minDelta] = 0
                self[chr]._weightMatrix[delta<=minDelta] = 0
            if maxDelta is not None:
                self[chr]._dataMatrix[delta>=maxDelta] = 0
                self[chr]._weightMatrix[delta>=maxDelta] = 0
                
