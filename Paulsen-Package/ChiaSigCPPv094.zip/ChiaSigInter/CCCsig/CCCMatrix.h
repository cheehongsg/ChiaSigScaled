// ChiaSig: detection of significant interactions in ChIA-PET data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2014) Jonas Paulsen


#ifndef GUARD_CCCMatrix
#define GUARD_CCCMatrix

#include "Segment.h"
#include <vector>
#include <set>
#include <map>
#include <utility>
#include <limits>

const int MAXDELTA = std::numeric_limits<int>::max();

typedef std::vector<std::vector<int> >::size_type MatrixIndex;
enum IndexType {NONINDEX, INTRAINDEX, ROWINDEX, COLINDEX};


template <class T> class CCCMatrix {
 public:
  CCCMatrix();
  CCCMatrix(std::set<Segment>, std::set<Segment>, T defaultvalue, bool);
  void printMatrix(bool hideMask=false);
  T getElement(Segment, Segment);
  void setElement(Segment, Segment, T);
  void setMask(Segment, Segment);
  bool isMasked(Segment, Segment);
  bool isValidRow(Segment);
  bool isValidColumn(Segment);
  T rowSum(Segment);
  T colSum(Segment);
  T weightedRowSum(Segment, std::map<Segment, float>);
  T avg();
  T sum();
  int nElem();
  
  std::set<Segment> getSegments(IndexType);
  std::vector<int> getDeltas(int minDelta=0, int maxDelta=MAXDELTA, bool masking=false);
  T getN(int minDelta=0, int maxDelta=MAXDELTA);
  void normalize();
  void scale(float);
  bool isIntra;
  MatrixIndex nRow, nCol; // Put to private eventually!  
 private:
  T defaultVal;
  T N;
  std::vector<std::vector<T> > matrix;
  std::vector<std::vector<bool> > mask;

  std::map<Segment, std::pair<MatrixIndex,IndexType> > getRowCol; 
};
#endif
