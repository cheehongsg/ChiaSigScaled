#include "../CCCsig/CCCStatistics.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

#include <cstdio>
#include <cstdlib>
#include <cmath> 
#include <vector>

#include "../stocc/stocc.h" // Non-central hypergeometric

using namespace std;




int main(int argc, char** argv) {

  assert( getPvalNCHG(50, 100, 50, 1000, 2.0) < 1E-50 );

  //cout << getPvalNCHG(15, 100, 500, 10000, 5.0) << " ~= " << "0.9331523 " << "?" << endl;
  assert( abs(getPvalNCHG(15, 100, 500, 10000, 5.0) - 0.9331523) < 0.00001);

  //cout << getPvalNCHG(1, 100, 500, 10000, 5.0) << " ~= " << "1.0 " << "?" << endl;
  assert( abs(getPvalNCHG(1, 100, 500, 10000, 5.0) - 1) < 0.00001);

  //cout << getPvalNCHG(5, 10, 25, 20000, 100.0) << " ~= " << "0.001730193 " << "?" << endl;
  assert( abs(getPvalNCHG(5, 10, 25, 20000, 100.0) - 0.001730193) < 0.00001);

  cout << argv[0] << ": Success!" << endl;
  return 0;

}
