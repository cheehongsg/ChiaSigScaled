#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

#include <stdlib.h> // abs

using namespace std;

int main( int argc, char *argv[] ) {
  Segment seg1("chr1", 1, 2);
  Segment seg2("chr1", 2, 3);
  Segment seg3("chr1", 3, 4);
  
  set<Segment> rowvec;
  
  rowvec.insert(seg1);
  rowvec.insert(seg2);
  rowvec.insert(seg3);

  CCCMatrix<int> myintramat(rowvec,rowvec, 3, true);


  map<int, float> delta2mean;
  //  delta2mean[0] = 0.0;
  delta2mean[1] = 1.1;
  delta2mean[2] = 2.2;

  ExpectationMatrix em = createExpectationMatrix(myintramat, delta2mean);
  //em.printMatrix();
  assert (em.getElement(seg1,seg1) == 0);
  assert (em.getElement(seg2,seg2) == 0);
  assert (em.getElement(seg3,seg3) == 0);


  cout << argv[0] << ": Success!" << endl;

  return 0;
}
