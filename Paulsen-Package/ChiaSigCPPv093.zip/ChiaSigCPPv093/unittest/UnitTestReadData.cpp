#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCDataReader.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>


using namespace std;

int main( int argc, char *argv[] ) {
  // Create a simple input file
  ofstream intrafile;
  intrafile.open("intramat.hjk1hhdf.txt");
  // Segments:
  // chr1 1 2
  // chr1 3 4
  // chr1 7 8
  // chr1 11 12

  // chr2 1 2
  // chr2 3 4
  // chr2 7 8
  // chr2 11 12

  intrafile << "chr1 1 2 chr1 3 4 1\nchr1 1 2 chr1 7 8 2\nchr1 1 2 chr1 11 12 3\nchr1 3 4 chr1 7 8 4\n";
  intrafile << "chr2 1 2 chr2 1 2 9\nchr2 3 4 chr2 7 8 5\nchr2 3 4 chr2 11 12 1\nchr2 3 4 chr2 7 8 8\n";
  intrafile.close();




  CCCDataReader dr("intramat.hjk1hhdf.txt");


  dr.buildContactMatrices();


  CCCMatrix<int> readmat1, readmat2;
  readmat1 = dr.getContactMatrix("chr1");
  readmat2 = dr.getContactMatrix("chr2");
  //cout << "toy matrix chr1:" << endl;
  //readmat1.printMatrix();
  //cout << "toy matrix chr2:" << endl;
  //readmat2.printMatrix();

  remove("intramat.hjk1hhdf.txt");

  set<Segment> segs1 = readmat1.getSegments(INTRAINDEX);

  //cout << "Colsums mat 1:" << endl;
  set<Segment>::iterator it;
  for (it = segs1.begin(); it != segs1.end(); ++it){
    Segment s = *it;
    //cout << readmat1.colSum(s) << endl;
  }
  //cout << "Testing if numbers are as specified in file in mat1" << endl;
  Segment seg1("chr1", 1, 2);
  Segment seg2("chr1", 3, 4);
  Segment seg3("chr2", 1, 2);

  assert(readmat1.getElement(seg1, seg2) == 1);
  assert(readmat1.getElement(seg2, seg1) == 1);

  //cout << "Testing if numbers are as specified in file in mat2" << endl;
  assert(readmat2.getElement(seg3, seg3) == 9);

  



  cout << argv[0] << ": Success!" << endl;
    
  
  return 0;
}
