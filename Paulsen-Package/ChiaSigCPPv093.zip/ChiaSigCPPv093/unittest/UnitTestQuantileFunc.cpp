#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"
#include "../CCCsig/CCCDataReader.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

#include <cstdio>
#include <cstdlib>
#include <vector>

#include "../stocc/stocc.h" // Non-central hypergeometric

//#include "splinetest.h"
//#include "spline/spline.h"

using namespace std;

int main(int argc, char** argv) {
  //cout << "Testing with lower_tail == true" << endl;
  assert(getQuantileNCHG(0.5, 40, 100, 500, 2.3, 1E-50,true) == 14);
  assert(getQuantileNCHG(0.05, 40, 100, 500, 2.3, 1E-50,true) == 9);
  assert(getQuantileNCHG(0.5, 40, 100, 500, 0.5, 1E-50,true) == 5);
  assert(getQuantileNCHG(0.05, 4, 41, 100, 20.3, 1E-50,true) == 3);
  assert(getQuantileNCHG(0.05, 20, 31, 70, 21, 1E-50,true) == 16);
  assert(getQuantileNCHG(0.05, 20, 31, 10000, 21, 1E-50,true) == 0);



  //cout << "Testing with lower_tail == false" << endl;
  assert(getQuantileNCHG(0.05, 4, 41, 100, 20.3, 1E-50, false) == 4); //
  assert(getQuantileNCHG(0.05, 8, 41, 100, 2.3, 1E-50, false) == 7);
  assert(getQuantileNCHG(0.05, 2, 31, 70, 21, 1E-50,false) == 2);
  assert(getQuantileNCHG(0.05, 20, 31, 70, 21, 1E-50,false) == 20);
  assert(getQuantileNCHG(0.05, 20, 31, 10000, 21,1E-50, false) == 3);

  cout << argv[0] << ": Success!" << endl;
  return 0;

}
